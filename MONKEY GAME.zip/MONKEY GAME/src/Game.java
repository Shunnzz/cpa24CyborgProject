import java.util.*;
import java.util.Stack;
import java.util.Queue;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

public class Game {
    static BinaryTree bestG = new BinaryTree();
    public static Stack<Game> playerHistory = new Stack<>();
    private String attempt;private int high;private double time;
    public Game (String attempt, int high, double time){this.attempt = attempt;this.high = high;this.time = time;}

    public static void menu(){
            System.out.println("Welcome To The Monkey Game!!!\n");
            System.out.println("1 - Play\n");
            System.out.println("2 - Exit\n");

            System.out.println("What would you like to do?: ");
            Scanner choice = new Scanner(System.in);
            int c = choice.nextInt();


            switch(c){
                case 1:
                    runner();
                    break;
                case 2:
                    System.exit(1);
                default:
                    System.out.println("Invalid Input: ");
                    System.out.println("\n");
                    System.out.println("\n");

                    menu();
                    break;
            }
    }

    public static void runner(){
        int play = 1;
        int gameCount = 1;
        while(play == 1){

            System.out.println("\nEnter Number of Games: ");
            Scanner num = new Scanner(System.in);
            int numG = num.nextInt();

            long startTime = System.currentTimeMillis();

            int newScore = playGame(numG);

            long endTime = System.currentTimeMillis();

            long totalTime = endTime - startTime;

            stats(newScore);
            playerHistory.add(new Game("Attempt " + gameCount, newScore, (double) totalTime/60000 ));

            bestG.insert(newScore);

            System.out.println("Play Again? 1 = Yes, 0 = No: ");
            Scanner again = new Scanner(System.in);
            play = again.nextInt();
            gameCount++;
        }

        while (!playerHistory.empty()) { //print games played
            System.out.print(playerHistory.peek().attempt + " \n");
            System.out.print("Level Reached:" + playerHistory.peek().high + " \n");
            System.out.print("Time: " + playerHistory.peek().time + " minutes reached \n");
            playerHistory.pop();
        }
        System.out.println("\n");
        System.out.println("\nHighest Level Reached is: LVL " + bestG.greatest());
    }

    public static void stats(int ns){
        System.out.println("\n");
        System.out.println("\n");
        System.out.println("Score: " + ns);
    }

    public static int playGame(int numG) {
        int levelWin = 0;

        for(int i = 0; i<numG; i++){

            ArrayList<Integer> numbers = new ArrayList<Integer>();

            for (int j = 0; j <= i; j++) {numbers.add(j+1);} // adding integers > 0

            for (int k = 0; k < 100 - i; k++) {numbers.add(0);} // adding 0 for fillers

            Collections.shuffle(numbers);

            int board[] = { // default board with no numbers
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0
            };

            for (int l = 0; l < 100; l++){board[l] = numbers.get(l);} // shuffled array to board


            String boardDisplay = ""; // for display
            for (int m = 0; m < 100; m++){ // generating display
                boardDisplay += board[m]; //adding number
                if(board[m] < 10){boardDisplay += " ";} // evening out the spacing if number is single digit
                boardDisplay += "  "; // spacing the numbers
                if(((m+1)%10 == 0)&&m!=0){boardDisplay += "\n";} // making a new line every 10 numbers
            }
            System.out.println(boardDisplay);

            try {
                Thread.sleep(3000);  // pause for 3000 milliseconds (3 seconds)
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            System.out.println("\n");// just to hide the OG board
            System.out.println("\n");
            System.out.println("\n");
            System.out.println("\n");
            System.out.println("\n");

            String hiddenDisplay = ""; // for hidden display
            for (int n = 0; n < 100; n++){ // generating display
                if (board[n] > 0){hiddenDisplay += "X ";} // replacing numbers (1, 2, 3...) with X
                else{hiddenDisplay += "0 ";} // place holders
                hiddenDisplay += "  "; // spacing
                if(((n+1)%10 == 0)&&n!=0){hiddenDisplay += "\n";} // making a new line every 10 numbers
            }
            System.out.println(hiddenDisplay);

            Queue<Integer> ansQueue = new LinkedList<>();

            for (int o = 0; o < i + 1; o++) {
                System.out.println("Enter Index of " + (o + 1));
                Scanner ans = new Scanner(System.in);
                int ansInt = ans.nextInt();
                ansQueue.add(ansInt);
            }

            int count = i + 1;
            for (int p = 0; p < i + 1; p++) {
                for (int q = 0; q < 100; q++) {
                    if (board[q] == p + 1 && q == (int) ansQueue.peek()) {
                        count--;
                        ansQueue.poll();
                    }
                }
            }

            if (count == 0) {
                System.out.println("CORRECT!");
                levelWin++;
            } else {
                System.out.println("WRONG!");
                return levelWin;
            }
        }
        return levelWin;
        }


    public static void main(String[] args) {
        menu();
    }
}