public class BinaryTree {
    class TreeNode {
        TreeNode left;
        TreeNode right;
        int data;

        TreeNode(int data) {
            left = null;
            right = null;
            this.data = data;
        }
    }

    TreeNode root;

    public BinaryTree() {
        root = null;
    }

    void insert(int d) {
        root = insertRec(root, d);
    }

    TreeNode insertRec(TreeNode root, int d) {
        if (root == null) {
            root = new TreeNode(d);
            return root;
        }
        //else traverse down the list
        else if (d < root.data) {
            root.left = insertRec(root.left, d);
        } else if (d > root.data) {
            root.right = insertRec(root.right, d);
        }
        return root;
    }

    void inorder() {
        inorderRec(root);
    }

    void inorderRec(TreeNode root) {
        if (root != null) {
            inorderRec(root.right);
            System.out.println(root.data + " ");
            inorderRec(root.left);
        }
    }

    public int greatest() {
        return greatestRec(root);
    }

    private int greatestRec(TreeNode node) {
        if (node == null) {
            throw new RuntimeException("The tree is empty");
        } else if (node.right == null) {
            return node.data;
        } else {
            return greatestRec(node.right);
        }
    }
}